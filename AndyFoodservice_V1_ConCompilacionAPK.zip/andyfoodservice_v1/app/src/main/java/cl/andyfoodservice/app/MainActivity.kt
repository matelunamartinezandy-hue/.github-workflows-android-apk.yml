package cl.andyfoodservice.app

import android.os.Bundle
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val orange = Color(0xFFE85D04)
private val teal = Color(0xFF2A9D8F)
private val weekdays = listOf("Lunes", "Martes", "Miércoles", "Jueves")
private val defaultMenu = linkedMapOf(
    "Lunes" to listOf("Arroz con carne mongoliana", "Arroz con hamburguesa"),
    "Martes" to listOf("Spaguettis con salsa de espinaca y pollo", "Spaguettis a la bolognesa"),
    "Miércoles" to listOf("Papas doradas con tiritas de pollo", "Puré con nugget"),
    "Jueves" to listOf("Salchipapas", "Papas fritas con suprema")
)

data class Student(val name: String, val school: String, val course: String)
data class Extra(val name: String, val price: Int)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AndyApp() }
    }
}

@Composable
fun AndyApp() {
    val context = LocalContext.current
    val prefs = remember(context) { context.getSharedPreferences("andy_foodservice_v1", Context.MODE_PRIVATE) }
    var screen by remember { mutableStateOf("home") }
    var studentName by remember { mutableStateOf("") }
    var school by remember { mutableStateOf("") }
    var course by remember { mutableStateOf("") }
    var students by remember {
        mutableStateOf(runCatching {
            val array = JSONArray(prefs.getString("students", "[]"))
            (0 until array.length()).map { i -> array.getJSONObject(i).let { Student(it.optString("name"), it.optString("school"), it.optString("course")) } }
        }.getOrDefault(emptyList()))
    }
    var activeStudent by remember { mutableStateOf<Student?>(null) }
    var menus by remember {
        mutableStateOf(runCatching {
            val obj = JSONObject(prefs.getString("menus", "{}"))
            if (obj.length() == 0) defaultMenu else weekdays.associateWith { day ->
                val arr = obj.optJSONArray(day) ?: JSONArray()
                (0 until arr.length()).map { arr.optString(it) }.ifEmpty { defaultMenu[day].orEmpty() }
            }
        }.getOrDefault(defaultMenu))
    }
    var lunchPrice by remember { mutableIntStateOf(prefs.getInt("lunchPrice", 5000)) }
    var saladPrice by remember { mutableIntStateOf(prefs.getInt("saladPrice", 800)) }
    var drinkPrice by remember { mutableIntStateOf(prefs.getInt("drinkPrice", 700)) }
    var dessertPrice by remember { mutableIntStateOf(prefs.getInt("dessertPrice", 700)) }
    var selections by remember { mutableStateOf(mapOf<String, String>()) }
    var extras by remember { mutableStateOf(mapOf<String, Set<String>>()) }
    var payPeriod by remember { mutableStateOf("Semanal") }
    var payTiming by remember { mutableStateOf("Anticipado") }
    var orderCount by remember { mutableIntStateOf(prefs.getInt("orderCount", 0)) }
    var lastOrderTotal by remember { mutableIntStateOf(prefs.getInt("lastOrderTotal", 0)) }
    var adminTab by remember { mutableStateOf("Pedidos") }
    var bankName by remember { mutableStateOf(prefs.getString("bankName", "") ?: "") }
    var bankAccount by remember { mutableStateOf(prefs.getString("bankAccount", "") ?: "") }

    // Guarda configuración localmente para que no se pierda al cerrar la app.
    LaunchedEffect(students) {
        val array = JSONArray()
        students.forEach { st -> array.put(JSONObject().put("name", st.name).put("school", st.school).put("course", st.course)) }
        prefs.edit().putString("students", array.toString()).apply()
    }
    LaunchedEffect(menus) {
        val obj = JSONObject()
        menus.forEach { (day, dishes) -> obj.put(day, JSONArray(dishes)) }
        prefs.edit().putString("menus", obj.toString()).apply()
    }
    LaunchedEffect(lunchPrice, saladPrice, drinkPrice, dessertPrice) {
        prefs.edit().putInt("lunchPrice", lunchPrice).putInt("saladPrice", saladPrice)
            .putInt("drinkPrice", drinkPrice).putInt("dessertPrice", dessertPrice).apply()
    }
    LaunchedEffect(bankName, bankAccount) {
        prefs.edit().putString("bankName", bankName).putString("bankAccount", bankAccount).apply()
    }
    LaunchedEffect(orderCount, lastOrderTotal) {
        prefs.edit().putInt("orderCount", orderCount).putInt("lastOrderTotal", lastOrderTotal).apply()
    }

    val extraOptions = listOf(Extra("Ensalada", saladPrice), Extra("Bebida", drinkPrice), Extra("Postre", dessertPrice))
    val total = selections.size * lunchPrice + extras.values.sumOf { chosen -> extraOptions.filter { it.name in chosen }.sumOf { it.price } }

    MaterialTheme(colorScheme = lightColorScheme(primary = orange, secondary = teal)) {
        Surface(Modifier.fillMaxSize()) {
            when (screen) {
                "home" -> Home(onParent = { screen = "register" }, onAdmin = { screen = "admin" })
                "register" -> Register(studentName, { studentName = it }, school, { school = it }, course, { course = it },
                    onContinue = {
                        if (studentName.isNotBlank() && school.isNotBlank() && course.isNotBlank()) {
                            val s = Student(studentName.trim(), school.trim(), course.trim())
                            students = students + s; activeStudent = s; screen = "menu"
                        }
                    }, onBack = { screen = "home" })
                "menu" -> OrderScreen(activeStudent, menus, selections, { day, dish -> selections = selections + (day to dish) },
                    extras, { day, extra ->
                        val now = extras[day].orEmpty()
                        extras = if (extra in now) extras + (day to (now - extra)) else extras + (day to (now + extra))
                    }, extraOptions, lunchPrice, total, payPeriod, { payPeriod = it }, payTiming, { payTiming = it },
                    onAddStudent = { screen = "register" }, onCheckout = { screen = "checkout" }, onBack = { screen = "home" })
                "checkout" -> Checkout(activeStudent, selections, extras, extraOptions, lunchPrice, total, payPeriod, payTiming,
                    bankName, bankAccount, { screen = "menu" }, onConfirm = { orderCount++; lastOrderTotal = total; screen = "confirmed" })
                "confirmed" -> Confirmed(orderCount, lastOrderTotal, onHome = {
                    selections = emptyMap(); extras = emptyMap(); activeStudent = null; screen = "home"
                })
                "admin" -> AdminScreen(
                    tab = adminTab, onTab = { adminTab = it }, students = students, orders = orderCount, total = lastOrderTotal,
                    menus = menus, onMenuChange = { day, idx, value ->
                        val newOptions = menus[day].orEmpty().toMutableList(); if (idx in newOptions.indices) newOptions[idx] = value
                        menus = menus + (day to newOptions)
                    }, lunchPrice = lunchPrice, onLunchPrice = { lunchPrice = it },
                    saladPrice = saladPrice, onSaladPrice = { saladPrice = it }, drinkPrice = drinkPrice, onDrinkPrice = { drinkPrice = it },
                    dessertPrice = dessertPrice, onDessertPrice = { dessertPrice = it }, bankName = bankName, onBankName = { bankName = it },
                    bankAccount = bankAccount, onBankAccount = { bankAccount = it }, onBack = { screen = "home" })
            }
        }
    }
}

@Composable fun Header(title: String) {
    Column(Modifier.fillMaxWidth().background(orange).padding(18.dp)) {
        Text("Andy Foodservice", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(title, color = Color.White.copy(alpha = .9f))
    }
}
@Composable fun Home(onParent: () -> Unit, onAdmin: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("Andy Foodservice", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = orange)
        Spacer(Modifier.height(8.dp)); Text("Almuerzos escolares · Lunes a jueves")
        Text("Precio inicial: $5.000 por almuerzo", color = Color.Gray)
        Spacer(Modifier.height(28.dp))
        Button(onClick = onParent, modifier = Modifier.fillMaxWidth().height(54.dp)) { Text("Pedir almuerzos") }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onAdmin, modifier = Modifier.fillMaxWidth().height(54.dp)) { Text("Panel de administración") }
        Spacer(Modifier.height(18.dp)); Text("Prototipo V1 · Los datos aún se guardan solo durante esta sesión", color = Color.Gray, fontSize = 12.sp)
    }
}
@Composable fun Register(name: String, onName: (String)->Unit, school: String, onSchool: (String)->Unit, course: String, onCourse: (String)->Unit, onContinue: ()->Unit, onBack: ()->Unit) {
    Column(Modifier.fillMaxSize()) { Header("Registro de alumno")
        Column(Modifier.padding(20.dp)) {
            Text("¿Para quién es el almuerzo?", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(name, onName, Modifier.fillMaxWidth(), label = { Text("Nombre del alumno") }, singleLine = true)
            OutlinedTextField(school, onSchool, Modifier.fillMaxWidth(), label = { Text("Colegio") }, singleLine = true)
            OutlinedTextField(course, onCourse, Modifier.fillMaxWidth(), label = { Text("Curso (ej. 7°A)") }, singleLine = true)
            Spacer(Modifier.height(20.dp)); Button(onClick = onContinue, enabled = name.isNotBlank() && school.isNotBlank() && course.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Continuar") }
            TextButton(onClick = onBack) { Text("Volver") }
        }
    }
}
@Composable fun OrderScreen(student: Student?, menus: Map<String,List<String>>, selections: Map<String,String>, onSelect: (String,String)->Unit,
    extras: Map<String,Set<String>>, onExtra: (String,String)->Unit, extraOptions: List<Extra>, lunchPrice: Int, total: Int,
    payPeriod: String, onPayPeriod: (String)->Unit, payTiming: String, onPayTiming: (String)->Unit,
    onAddStudent: ()->Unit, onCheckout: ()->Unit, onBack: ()->Unit) {
    Column(Modifier.fillMaxSize()) {
        Header("Menú y pedido semanal")
        Column(Modifier.padding(horizontal=16.dp, vertical=8.dp)) {
            Text(student?.name ?: "Alumno", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("${student?.school.orEmpty()} · ${student?.course.orEmpty()}", color = Color.Gray)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedButton(onClick=onAddStudent) { Text("+ Otro alumno") }; TextButton(onClick=onBack) { Text("Inicio") } }
        }
        LazyColumn(Modifier.weight(1f), contentPadding=PaddingValues(horizontal=16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
            items(weekdays) { day ->
                Card(shape=RoundedCornerShape(14.dp)) { Column(Modifier.padding(14.dp)) {
                    Text(day, fontSize=18.sp, fontWeight=FontWeight.Bold)
                    menus[day].orEmpty().forEach { dish -> Row(verticalAlignment=Alignment.CenterVertically) {
                        RadioButton(selected=selections[day]==dish, onClick={onSelect(day,dish)})
                        Text(dish, modifier=Modifier.weight(1f))
                    } }
                    if (selections[day] != null) {
                        Spacer(Modifier.height(6.dp)); Text("Extras para este almuerzo", fontWeight=FontWeight.SemiBold)
                        extraOptions.forEach { extra -> Row(verticalAlignment=Alignment.CenterVertically) {
                            Checkbox(checked=extra.name in extras[day].orEmpty(), onCheckedChange={onExtra(day,extra.name)})
                            Text("${extra.name} · $${extra.price}")
                        } }
                    } else Text("Selecciona un almuerzo para habilitar extras", color=Color.Gray, fontSize=12.sp)
                } }
            }
            item {
                Card { Column(Modifier.padding(14.dp)) {
                    Text("Modalidad de pago", fontSize=18.sp, fontWeight=FontWeight.Bold)
                    listOf("Semanal","Mensual").forEach { Row(verticalAlignment=Alignment.CenterVertically) { RadioButton(selected=payPeriod==it,onClick={onPayPeriod(it)}); Text(it) } }
                    Text("¿Cuándo pagarás?", fontWeight=FontWeight.SemiBold)
                    listOf("Anticipado","Al finalizar el período").forEach { Row(verticalAlignment=Alignment.CenterVertically) { RadioButton(selected=payTiming==it,onClick={onPayTiming(it)}); Text(it) } }
                    Text("Solo transferencia bancaria", color=teal, fontWeight=FontWeight.Bold)
                } }
            }
        }
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("Total estimado", color=Color.Gray); Text("$${total}", fontSize=22.sp, fontWeight=FontWeight.Bold) }
            Button(onClick=onCheckout, enabled=selections.isNotEmpty()) { Text("Continuar") }
        }
    }
}
@Composable fun Checkout(student: Student?, selections: Map<String,String>, extras: Map<String,Set<String>>, extraOptions: List<Extra>, lunchPrice: Int, total: Int,
    period: String, timing: String, bankName: String, bankAccount: String, onBack: ()->Unit, onConfirm: ()->Unit) {
    Column(Modifier.fillMaxSize()) { Header("Confirmación del pedido")
        LazyColumn(Modifier.weight(1f), contentPadding=PaddingValues(20.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
            item { Text("Alumno: ${student?.name.orEmpty()}", fontWeight=FontWeight.Bold, fontSize=20.sp); Text("${student?.school.orEmpty()} · ${student?.course.orEmpty()}") }
            items(selections.toList()) { (day,dish) -> Card { Column(Modifier.padding(12.dp)) {
                Text(day, fontWeight=FontWeight.Bold); Text(dish); Text("Almuerzo: $${lunchPrice}")
                extras[day].orEmpty().forEach { name -> Text("+ $name · $${extraOptions.firstOrNull { it.name==name }?.price ?: 0}") }
            } } }
            item { Text("Pago $period · $timing", fontWeight=FontWeight.SemiBold); Text("Medio de pago: transferencia bancaria")
                if (bankName.isNotBlank() || bankAccount.isNotBlank()) Text("Datos de transferencia: $bankName · $bankAccount")
                else Text("Los datos bancarios serán informados por Andy Foodservice al habilitar el sistema de pagos.", color=Color.Gray)
                Spacer(Modifier.height(8.dp)); Text("Total: $${total}", fontSize=26.sp, fontWeight=FontWeight.Bold)
                Text("Esta V1 es una demostración: no envía pedidos ni verifica transferencias todavía.", color=Color(0xFF9A3412), fontSize=12.sp)
            }
        }
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement=Arrangement.spacedBy(10.dp)) { OutlinedButton(onClick=onBack, modifier=Modifier.weight(1f)){Text("Volver")}; Button(onClick=onConfirm, modifier=Modifier.weight(1f)){Text("Registrar demo") } }
    }
}
@Composable fun Confirmed(order: Int, total: Int, onHome: ()->Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) {
        Text("✓", fontSize=60.sp, color=teal); Text("Pedido de prueba registrado", fontSize=25.sp, fontWeight=FontWeight.Bold)
        Text("Referencia local: #${1000+order}"); Text("Total estimado: $${total}")
        Text("Esto no es todavía una confirmación real para la cocina.", color=Color.Gray, fontSize=13.sp)
        Spacer(Modifier.height(24.dp)); Button(onClick=onHome) { Text("Volver al inicio") }
    }
}
@Composable fun AdminScreen(tab: String, onTab:(String)->Unit, students: List<Student>, orders: Int, total: Int,
    menus: Map<String,List<String>>, onMenuChange:(String,Int,String)->Unit,
    lunchPrice:Int, onLunchPrice:(Int)->Unit, saladPrice:Int, onSaladPrice:(Int)->Unit, drinkPrice:Int, onDrinkPrice:(Int)->Unit,
    dessertPrice:Int, onDessertPrice:(Int)->Unit, bankName:String, onBankName:(String)->Unit, bankAccount:String, onBankAccount:(String)->Unit, onBack:()->Unit) {
    var pLunch by remember(lunchPrice) { mutableStateOf(lunchPrice.toString()) }; var pSalad by remember(saladPrice) { mutableStateOf(saladPrice.toString()) }
    var pDrink by remember(drinkPrice) { mutableStateOf(drinkPrice.toString()) }; var pDessert by remember(dessertPrice) { mutableStateOf(dessertPrice.toString()) }
    Column(Modifier.fillMaxSize()) { Header("Panel de administración")
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceEvenly) { listOf("Pedidos","Menús","Precios","Transferencia").forEach { TextButton(onClick={onTab(it)}) { Text(if(tab==it) "• $it" else it) } } }
        LazyColumn(Modifier.weight(1f), contentPadding=PaddingValues(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
            when(tab) {
                "Pedidos" -> { item { Text("Resumen", fontSize=22.sp, fontWeight=FontWeight.Bold); Text("Pedidos registrados en esta sesión: $orders"); Text("Último total registrado: $${total}"); Text("Los pedidos aún no se guardan en una base de datos compartida.", color=Color.Gray) }; item { Text("Alumnos ingresados", fontWeight=FontWeight.Bold) }; items(students) { Text("${it.name} · ${it.school} · ${it.course}") } }
                "Menús" -> { items(weekdays) { day -> Card { Column(Modifier.padding(12.dp)) { Text(day, fontWeight=FontWeight.Bold, fontSize=18.sp); menus[day].orEmpty().forEachIndexed { idx, dish -> var value by remember(dish) { mutableStateOf(dish) }; OutlinedTextField(value, { value=it; onMenuChange(day,idx,it) }, Modifier.fillMaxWidth(), label={Text("Opción ${idx+1}")}) } } } } }
                "Precios" -> { item { Text("Editar precios (CLP)", fontSize=22.sp, fontWeight=FontWeight.Bold)
                    OutlinedTextField(pLunch,{pLunch=it},Modifier.fillMaxWidth(),label={Text("Almuerzo")}); OutlinedTextField(pSalad,{pSalad=it},Modifier.fillMaxWidth(),label={Text("Ensalada")}); OutlinedTextField(pDrink,{pDrink=it},Modifier.fillMaxWidth(),label={Text("Bebida")}); OutlinedTextField(pDessert,{pDessert=it},Modifier.fillMaxWidth(),label={Text("Postre")})
                    Button(onClick={pLunch.toIntOrNull()?.let(onLunchPrice);pSalad.toIntOrNull()?.let(onSaladPrice);pDrink.toIntOrNull()?.let(onDrinkPrice);pDessert.toIntOrNull()?.let(onDessertPrice)}, modifier=Modifier.fillMaxWidth()) { Text("Guardar precios en esta sesión") }
                } }
                else -> { item { Text("Datos bancarios", fontSize=22.sp, fontWeight=FontWeight.Bold); OutlinedTextField(bankName,onBankName,Modifier.fillMaxWidth(),label={Text("Banco / titular")}); OutlinedTextField(bankAccount,onBankAccount,Modifier.fillMaxWidth(),label={Text("Datos de cuenta o instrucciones")}); Text("No ingreses claves bancarias. La verificación de transferencias será manual.", color=Color.Gray); } }
            }
        }
        TextButton(onClick=onBack, modifier=Modifier.align(Alignment.Start).padding(start=12.dp)) { Text("Volver al inicio") }
    }
}
