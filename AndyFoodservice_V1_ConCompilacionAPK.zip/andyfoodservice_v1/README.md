# Andy Foodservice V1 — prototipo Android

Proyecto Android nativo con Jetpack Compose para avanzar en la aplicación de pedidos de almuerzos escolares.

## Funciones disponibles en este prototipo
- Registro local de alumnos con nombre, colegio y curso.
- Menú de lunes a jueves con dos opciones de ejemplo por día.
- Selección de almuerzo por día.
- Extras asociados a un almuerzo: ensalada, bebida y postre.
- Precio inicial del almuerzo de $5.000 CLP.
- Edición local de precios para almuerzo y extras.
- Selección de pago semanal o mensual y anticipado o al finalizar el período.
- Configuración local de datos/instrucciones para transferencia.
- Panel local para editar menú, precios y datos bancarios.
- Resumen de pedido y referencia local de demostración.
- Persistencia local de alumnos, menús, precios, datos bancarios y contadores mediante SharedPreferences; estos datos se mantienen en el mismo dispositivo al cerrar y volver a abrir la app.

## Limitaciones antes de usar con clientes
Este proyecto todavía es un prototipo y no debe usarse para recibir pedidos reales. No tiene backend/base de datos compartida entre apoderados y administración, cuentas autenticadas, carga real de comprobantes, notificaciones ni verificación de transferencias. El contador de pedidos y el resumen son demostrativos; no se almacena aún un registro completo de cada pedido. Los datos bancarios deben ser configurados por el dueño y revisados antes de cualquier uso real.

## Compilación
Abrir la carpeta en Android Studio con Android SDK y Gradle configurados, sincronizar el proyecto y ejecutar `assembleDebug` para crear una APK de prueba. Este paquete no incluye Gradle Wrapper ni una APK compilada.

## Obtener una APK de prueba sin instalar Android Studio en el computador
Este proyecto incluye un flujo de compilación en GitHub Actions (`.github/workflows/android-apk.yml`). Para usarlo:
1. Sube esta carpeta a un repositorio de GitHub (por ejemplo, `AndyFoodserviceV1`).
2. Abre la pestaña **Actions** y selecciona **Build Android APK**.
3. Pulsa **Run workflow** (o espera a que termine una ejecución tras subir cambios).
4. Cuando termine correctamente, entra a la ejecución y descarga el artefacto **AndyFoodservice-debug-APK**. Dentro estará `app-debug.apk`.

La APK generada de esta manera será una APK **debug de prueba**, no una versión publicada ni una garantía de que el prototipo esté listo para recibir pedidos reales. Antes de operar con clientes sigue siendo necesario completar backend compartido, cuentas, registro real de pedidos y comprobantes de transferencia, además de probar el flujo en dispositivos Android.
